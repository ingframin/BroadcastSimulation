create table scans(
    rel_time float primary key,
    ssid varchar(64),
    node int
);